/*
 * LoginFormTest 
 * Code Monkeys Triston, Bonnie, Bunmi, Natacha, Kristen and Taylor
 * code redone as of march 21
 * CIST 2931 DeRiche
 */
package Presentation;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Triston_Gregoire
 */
public class LoginFormTest {
    
    /**
     *
     */
    public LoginFormTest() {
    }
    
    /**
     *
     */
    @BeforeClass
    public static void setUpClass() {
    }
    
    /**
     *
     */
    @AfterClass
    public static void tearDownClass() {
    }
    
    /**
     *
     */
    @Before
    public void setUp() {
    }
    
    /**
     *
     */
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class LoginForm.
     * the main method is used just for testing purposes
     */
    @Test
    
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        LoginForm.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
